package com.demo.testemployee;

import java.util.Map;
import java.util.TreeMap;

import com.demo.beans.Employee;

public class EmployeeTreeMapDemo {
    public static void main(String[] args) {
        TreeMap<Integer, Employee> employeeMap = new TreeMap<>();

        // Adding employees to the TreeMap
        Employee emp1 = new Employee(1, "prathmesh kamble", 50000, "MD,MBBS", "MD in medicince");
		Employee emp2 = new Employee(2, "mustafa mulla", 60000, "HR", "HR Manager");
		Employee emp3 = new Employee(3, "pranv khot", 70000, "Finance", "Financial Analyst");
		Employee emp4 = new Employee(4, "abhisheak patil", 55000, "IT", "System Administrator");
		Employee emp5 = new Employee(4, "abhisheak patil", 55000, "IT", "System Administrator");
		
        employeeMap.put(emp1.getId(), emp1);
        employeeMap.put(emp2.getId(), emp2);
        employeeMap.put(emp3.getId(), emp3);
        employeeMap.put(emp4.getId(), emp4);
        employeeMap.put(emp5.getId(), emp5);// tree map will not allow any duplicate value and so 

        // Trying to add emp1 again, it won't be added since it's a duplicate
        employeeMap.put(emp1.getId(), emp1);

        // Displaying the employee map
        for (Map.Entry<Integer, Employee> entry : employeeMap.entrySet()) {
            Employee employee = entry.getValue();
            System.out.println(employee.getName() + " - " + employee.getDepartment());
        }
    }
}