package com.demo.testemployee;

import java.util.HashSet;

import com.demo.beans.Employee;

public class EmployeeHashSetDemo {



	public static void main(String[] args) {
		HashSet<Employee> employeeSet = new HashSet<>();

		// Adding employees to the HashSet
		Employee emp1 = new Employee(1, "prathmesh kamble", 50000, "MD,MBBS", "MD in medicince");
		Employee emp2 = new Employee(2, "mustafa mulla", 60000, "HR", "HR Manager");
		Employee emp3 = new Employee(3, "pranv khot", 70000, "Finance", "Financial Analyst");
		Employee emp4 = new Employee(4, "abhisheak patil", 55000, "IT", "System Administrator");
		Employee emp5 = new Employee(4, "abhisheak patil", 55000, "IT", "System Administrator");

		employeeSet.add(emp1);
		employeeSet.add(emp2);
		employeeSet.add(emp3);
		employeeSet.add(emp4);
		employeeSet.add(emp5);//id is same for emp. hashset will not take duplicate values.

		// Trying to add emp1 again, it won't be added since it's a duplicate
		employeeSet.add(emp1);

		// Displaying the employee set
		for (Employee employee : employeeSet) {
			System.out.println(employee.getName() + " - " + employee.getDepartment());
		}
	}

}


