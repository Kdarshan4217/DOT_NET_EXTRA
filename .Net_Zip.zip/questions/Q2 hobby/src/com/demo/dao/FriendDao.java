package com.demo.dao;

import com.demo.bean.Friend;
import com.demo.service.IFriendService;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;

public class FriendDao implements IFriendDao {
	
	static List<Friend> list;
	static {
		list = new ArrayList<>();
		List <String> lst1=List.of("Singing","Dancing");
		List <String> lst2=List.of("Reading","Singing","Sketching");
		
	
		
		list.add(new Friend(1,"Rama",lst1,"12345678","rama@gmail.com",LocalDate.of(1194, 03, 24),"Maharashtra"));
		list.add(new Friend(2,"Sita",lst2,"23200123","sita@gmail.com",LocalDate.of(1994, 12, 11),"Punjab"));
		
	}
	@Override
	public List<Friend> display() {
		
		return list;
	}
	@Override
	public Friend SerachId(int id) {
		for(Friend f:list) {
			if(f.getId()==id) {
				return f;
			}
		}
		return null;
	}
	@Override
	public List<Friend> SearchName(String name) {
		List<Friend> l = new ArrayList<>();
		for(Friend f:list) {
			if(f.getLastname().equals(name)) {
				l.add(f);
			}
		}
		if(l.isEmpty()) {
			return null;
		}
		return l;
	}
	@Override
	public List<Friend> displayH(String h) {
		List<Friend> lst = new ArrayList<>();
		for(Friend s:list) {
			for(String hb:s.getHobbies()) {
			if(hb.equals(h)) {
			lst.add(s);
		}
			
			}
			return lst;
		}
		return null;
	}

}
