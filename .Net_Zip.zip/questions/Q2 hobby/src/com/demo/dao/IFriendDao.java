package com.demo.dao;


import java.util.List;

import com.demo.bean.*;

public interface IFriendDao {
	List<Friend> display();

	Friend SerachId(int id);

	List<Friend> SearchName(String name);

	List<Friend> displayH(String h);
}
