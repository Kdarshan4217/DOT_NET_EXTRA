package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Friend;
import com.demo.service.*;

public class TestFriend {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		IFriendService fservice = new FriendService();
		int choice;
		do {
		System.out.println("Enter your Choice:");
		System.out.println("1.DisplayAll \n 2.Search by Id \n 3.Search By Name \n 4.Search with particular Hobbie\n 5.exit");
		choice = sc.nextInt();
		
		switch(choice) {
		case 1:
			List<Friend> lst = fservice.displayAll();
			System.out.println(lst);
			break;
		case 2:
			System.out.println("enter id to search");
			int id = sc.nextInt();
			Friend f = fservice.SearchById(id);
			System.out.println(f);
			break;
		case 3:
			System.out.println("enter id to name");
			String name = sc.next();
			List<Friend> l= fservice.SearchByName(name);
			System.out.println(l);
			break;
		case 4:
			System.out.println("Enter the Hobby");
			String h = sc.next();
			List<Friend> list = fservice.displayHobbie(h);
			System.out.println(list);
			break;
		case 5:
		System.out.println("Exited!!");
			break;
		default:
			System.out.println("Invaaalild choice!!!!!!!");
			break;
		}
		}while(choice!=5);
		sc.close();
	}

}
