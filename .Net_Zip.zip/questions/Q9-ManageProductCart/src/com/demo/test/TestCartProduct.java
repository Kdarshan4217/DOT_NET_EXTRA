package com.demo.test;

import com.demo.service.CartService;

public class TestCartProduct 
{
	public static void main(String[] args) 
	{
		CartService.displayMenu();
	}
}





