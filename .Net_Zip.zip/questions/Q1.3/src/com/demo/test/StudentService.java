package com.demo.test;
import java.util.Scanner;

public class StudentService {

	static int m1,m2,m3;
	static float gpa;
	public static void addnewStudent(Student[] sarr) {
		
			Scanner scn=new Scanner(System.in);
			
			
		  
			for(int i=0;i<sarr.length;i++)
			{
				
				System.out.println("Enter Student Id: ");
				int id=scn.nextInt();
		
				System.out.println("Enter Student Name: ");
				String name=scn.next();
		
				System.out.println("Enter Marks 1");
				 m1=scn.nextInt();
		
				System.out.println("Enter Marks 2");
				 m2=scn.nextInt();
		
				System.out.println("Enter Marks 3");
				 m3=scn.nextInt();
		
				sarr[i] = new Student(id,name,m1,m2,m3);
		}
	}

	public static void displayAllDetails(Student[] sarr) {
		for(int i=0;i<sarr.length;i++)
		{
			System.out.println(sarr[i]);
		}

		
	}

	public static Student searchById(Student[] sarr, int id) {
		for(Student s:sarr)
		{
			if(s.getSid()==id)
			{
				return s;
			}
		}
		
		return null;
	}

	public static Student searchByName(Student[] sarr, String name) {
		
		for(Student s:sarr)
		{
			if(s.getSname().equals(name));
			{
				return s;
			}
		}
		return null;
	}

	public static void displayGPA(Student[] sarr, int sid) 
	{
//		gpa=(1/3)*m1+(1/2)*m2+(1/4)*m3
		gpa = ((1/3)*m1)+((1/2)*m2)+((1/4)*m3);
		System.out.println("GPA is : "+gpa);
		
	}

	
}
