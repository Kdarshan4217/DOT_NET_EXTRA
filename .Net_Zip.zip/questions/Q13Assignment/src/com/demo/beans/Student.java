package com.demo.beans;

public class Student
{
		private int studid;
		private String sname;
		private String degree;
		private String email;
		public Student() {
			super();
		}
		public Student(int studid, String sname, String degree, String email) {
			super();
			this.studid = studid;
			this.sname = sname;
			this.degree = degree;
			this.email = email;
		}
		public int getStudid() {
			return studid;
		}
		public void setStudid(int studid) {
			this.studid = studid;
		}
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public String getDegree() {
			return degree;
		}
		public void setDegree(String degree) {
			this.degree = degree;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		@Override
		public String toString() {
			return "Student [studid=" + studid + ", sname=" + sname + ", degree=" + degree + ", email=" + email + "]";
		}
		
		
}



