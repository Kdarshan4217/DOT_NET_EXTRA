package com.demo.test;
//Q13. Modify code written in Q11. By using ObjectOutputStream to write data to file
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.demo.beans.Student;
public class TestObjectIOstream {

	public static void main(String[] args) 
	{
		Student s1= new Student (101,"Gauri","BE","grk@gamil.com");
		Student s2= new Student (102,"Himanshu","BE","him@gamil.com");
		Student s3= new Student (103,"Harshay","BE","har@gamil.com");
		Student s4= new Student (104,"Shrijay","BE","shri@gamil.com");
		Student s5 = new Student(105,"Madhura","BE","madhu@gamil.com");
		
		List<Student> slist = new ArrayList<>();
		slist.add(s1);
		slist.add(s2);
		slist.add(s3);
		slist.add(s4);
		slist.add(s5);
		
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("studentdetails.csv"));) 
		{
			for(Student s: slist)
			{
				oos.writeUTF("   "+s.getStudid()+"  "+s.getSname()+"  "+s.getDegree()+"  "+s.getEmail()+"\n");
			}
			System.out.println("doneeeee");
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("studentdetails.csv"));) 
		{
			String s =ois.readLine();
			while(s!=null) {
				System.out.println(s);
				s=ois.readLine();
			}
		
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}

}
