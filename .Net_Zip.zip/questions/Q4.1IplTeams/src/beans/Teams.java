package beans;

import java.util.List;


public class Teams {
	 private int teamid;
	 private String tname;
	 private String coachname;
	 private List<String> players;
	public Teams(int teamid, String tname, String coachname, List<String> players) {
		super();
		this.teamid = teamid;
		this.tname = tname;
		this.coachname = coachname;
		this.players = players;
	}
	public Teams(int teamid) {
		this.teamid=teamid;
	}
	public int getTeamid() {
		return teamid;
	}
	public void setTeamid(int teamid) {
		this.teamid = teamid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getCoachname() {
		return coachname;
	}
	public void setCoachname(String coachname) {
		this.coachname = coachname;
	}
	public List<String> getPlayers() {
		return players;
	}
	public void setPlayers(List<String> players) {
		this.players = players;
	}
	@Override
	public String toString() {
		return "Teams [teamid=" + teamid + ", tname=" + tname + ", coachname=" + coachname + ", players=" + players
				+ "]";
	}
	 
	 
}
