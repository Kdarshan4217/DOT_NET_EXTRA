package dao;

import java.util.ArrayList;
import java.util.List;

import beans.Teams;

public class TeamDaoImpl implements TeamDao{

	static List<Teams> list ;
	
	
	static {
	list = new ArrayList<>();
		
	}
	@Override
	public boolean addT(Teams e) {
		
		return list.add(e);
	}

	@Override
	public void displayT() {
		System.out.println(list);
		
	}

	@Override
	public boolean removePlr(int id,String plr) {
		for(Teams t:list) {
			if(id==t.getTeamid()) {
			return t.getPlayers().remove(plr);
		}
		}
		return false;
	}

	@Override
	public boolean removeTeam(int tid) {
		return list.remove(new Teams(tid));
	}

	@Override
	public boolean addC(int tid,String coach) {
		for(Teams t:list) {
			if(tid==t.getTeamid()) {
				t.setCoachname(coach);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean addPlayer(int tid, String pname) {
		for(Teams t:list) {
			if(tid==t.getTeamid()) {
				return t.getPlayers().add(pname);
				
			}
		}
		return false;
	}

}
