package dao;

import beans.Teams;

public interface TeamDao {

	boolean addT(Teams e);

	void displayT();

	  boolean removePlr(int id, String plr);

	boolean removeTeam(int tid);

	boolean addC(int tid, String coach);

	boolean addPlayer(int tid, String pname);

}
