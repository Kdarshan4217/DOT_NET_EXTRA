package service;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import beans.Teams;
import dao.TeamDao;
import dao.TeamDaoImpl;

public class TeamServiceImpl implements TeamService {

	private TeamDao tdao;
	public TeamServiceImpl() {
		this.tdao = new TeamDaoImpl();
	}
	@Override
	public boolean addNew() {
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter id:");
		int teamid = sc.nextInt();
		System.out.println("Enter name:");
		String tname = sc.next();
		System.out.println("Enter coachname:");
		String coachname = sc.next();
		
		 List<String> players= new ArrayList<>();
		for(int i=0;i<2;i++){
			System.out.println("Enter Player name:");
			String pname = sc.next();
			
			 players.add(pname);
			 System.out.println("added");
			
		}
		
		Teams e = new Teams(teamid,tname,coachname,players);
		System.out.println(e);
		return tdao.addT(e);
	}
	@Override
	public void displayAll() {
		tdao.displayT();
		
	}
	@Override
	public boolean removeP(int id,String plr) {
		return tdao.removePlr(id,plr);
	}
	@Override
	public boolean removeT(int tid) {
		return tdao.removeTeam(tid);
	}
	@Override
	public boolean addCoach(int tid,String coach) {
		return tdao.addC(tid,coach);
	}
	@Override
	public boolean addP(int tid, String pname) {
		return tdao.addPlayer(tid,pname);
	}

}
