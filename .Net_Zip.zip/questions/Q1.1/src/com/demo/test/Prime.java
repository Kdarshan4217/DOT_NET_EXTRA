package com.demo.test;

import java.util.Scanner;

public class Prime {

public static void main(String[] args) {
	Scanner scn=new Scanner(System.in);
	int [] num=new int[3];
	
	for(int i=0;i<3;i++)
	{
		System.out.println("Enter "+(i+1)+" number");
		num[i] = scn.nextInt();
//		num[i]=Integer.parseInt(args[i]);
		
	}
	boolean flag = true;
	for(int i=0;i<3;i++)
	{
		
		for(int j=2;j<=num[i]/2;j++)
		{
			if(num[i]%j==0)
			{
				flag =false;
				break;
				}
			}
		
		if(flag== true) {
				for(int k=1;k<=10;k++)
				{
					System.out.println("Table is: "+num[i]+" * "+k+" = "+num[i]*k);
					
				}
				System.out.println("-------------------------------------------");}
				else
			{
				int res=num[i]/10;
				System.out.println("result is: "+res);
			}}
		}
		

	
	
	
	
}


