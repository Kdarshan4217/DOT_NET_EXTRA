package com.demo.test;
import java.util.Scanner;
//Q17. Create enumerator grade and store following objects 
//Distinction(80,100),First(65,79),Second(50,64),Pass(40,49),Fail(0,39)
//Accept grade from user and display minimum and maximum marks for the grade.
public class Q17_Enum 
{

	public static void main(String[] args) 
	{
	
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a grade ('Distinction', 'First','Second','Pass','Fail' ): ");
        String user = scanner.nextLine();
        scanner.close();
        Grade grade = Grade.valueOf(user); //user value of function for user
		
		switch(grade)
		{
		case Distinction:
			System.out.println("You Passed With Distinction "+grade.getMax()+" "+grade.getMin());
			break;
		case First:
			System.out.println("You Passed With First "+grade.getMax()+" "+grade.getMin());
			break;
		case Second:
			System.out.println("You Passed With Second "+grade.getMax()+" "+grade.getMin());
			break;
		case Pass:
			System.out.println("You Passed "+grade.getMax()+" "+grade.getMin());
			break;
		case Fail:
			System.out.println("You Failed"+grade.getMax()+" "+grade.getMin());
			break;
		}

	}

}
