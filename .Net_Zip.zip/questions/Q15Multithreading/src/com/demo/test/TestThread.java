package com.demo.test;
import java.io.FileNotFoundException;
import java.io.IOException;
import com.demo.threads.*;
import com.demo.storage.*;

public class TestThread {

	public static void main(String[] args) {
		Storage storage = new Storage();
		Producer producer = new Producer(storage);
		Consumer consumer =new Consumer(storage);
		
		producer.start();
		consumer.start();
	}
	
}
