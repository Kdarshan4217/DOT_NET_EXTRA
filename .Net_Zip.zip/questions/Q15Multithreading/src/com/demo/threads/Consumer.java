package com.demo.threads;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.demo.storage.Storage;

public class Consumer extends Thread {
	private Storage sobj;
	
	public Consumer(Storage sobj) 
	{
		super();
		this.sobj = sobj;
	}
	
	public Consumer() {
		super();
		
	}
	public void run()
	{
			try {
				sobj.get();
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Product Write Successful..");
	}
	
}
