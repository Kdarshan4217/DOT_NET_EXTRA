package com.demo.threads;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.demo.storage.Storage;

public class Producer extends Thread{
	private Storage sobj;

	public Producer(Storage sobj) {
		super();
		this.sobj = sobj;
	}
	
	public void run()
	{
		try {
			sobj.put();
			System.out.println("Product Read Successful..");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
