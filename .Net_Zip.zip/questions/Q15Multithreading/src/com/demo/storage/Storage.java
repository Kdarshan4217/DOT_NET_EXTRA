package com.demo.storage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Storage {
	private String[] data;
	private boolean state;
	private int amount,qty,price;
	
	public Storage()
	{
		state =false;
	}
	
	synchronized public void put() throws InterruptedException, FileNotFoundException, IOException
	{
		if(state)
		{
			wait();
		}
		//logic
		try(BufferedReader br = new BufferedReader(new FileReader("productdata.dat"));)
		{
			String s = br.readLine();
		   data= s.split(",");
			for(String str:data)
			{
				System.out.println(str);
			}	
		}
		state= true;
		notify();
	}
	
	public synchronized void get() throws InterruptedException, IOException
	{
		if(!state)
		{
			wait();
		}
		//logic 
		 qty= Integer.parseInt(data[1]);
		 price= Integer.parseInt(data[3]);
		 amount =qty * price + 10% price;
		 
		 try(BufferedWriter br = new BufferedWriter(new FileWriter("productamount.dat"));)
			{
			 br.write("Product\n Id= 101\n Name = Lays\n Qty = "+qty+"\n Price = "
					 +price+"\n Amount = "+amount);
			}
	
		state= false;
		notify();
	}
}


