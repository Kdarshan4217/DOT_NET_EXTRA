package com.demo.test;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class TestObjectStream {

public static void main(String[] args) {
				try(ObjectInputStream ois= new ObjectInputStream(new FileInputStream("studentdetails.csv"));) 
				{
						String s =ois.readUTF();
						while(s!=null) 
						{
							System.out.println(s);
							s=ois.readUTF();
						}
						System.out.println("End of File");
					} catch (IOException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

			}

	}


