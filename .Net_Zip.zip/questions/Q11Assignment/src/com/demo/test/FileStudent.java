package com.demo.test;
import com.demo.beans.Student;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;

public class FileStudent {

	public static void main(String[] args) 
	{
		Student s1= new Student (101,"Madhura","BE","grk@gamil.com");
		Student s2= new Student (102,"Kunal","BE","him@gamil.com");
		Student s3= new Student (103,"Harshay","BE","har@gamil.com");
		Student s4= new Student (104,"Shrijay","BE","shri@gamil.com");
		Student s5 = new Student(105,"Gauri","BE","madhu@gamil.com");
		
		List<Student> slist = new ArrayList<>();
		slist.add(s1);
		slist.add(s2);
		slist.add(s3);
		slist.add(s4);
		slist.add(s5);
		
		try(BufferedWriter bw = new BufferedWriter(new FileWriter("studentdata.csv"));) 
		{
			for(Student s: slist)
			{
				bw.write("   "+s.getStudid()+"  "+s.getSname()+"  "+s.getDegree()+"  "+s.getEmail()+"\n");
			}
			System.out.println("doneeeee");
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try(BufferedReader br = new BufferedReader(new FileReader("studentdata.csv"));) 
		{
			String s =br.readLine();
			while(s!=null) {
				System.out.println(s);
				s=br.readLine();
			}
		
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
