package dao;

import java.util.List;

import beans.Employee;

public interface EmployeeDao {

	void display();

	Employee searchid(int id);

	Employee searchname(String nm);

	List<Employee> deptartment(String dept);

	List<Employee> searchbydsg(String dsg);

}
