package beans;

import java.time.LocalDate;

public class SalaryEmp extends Employee{


private float sal;
public SalaryEmp(int id, String name, String mob, String emailid, String dept, String desig, LocalDate joindate,float sal) {
	super(id, name, mob, emailid, dept, desig);
	this.sal = sal;
}
public float getSal() {
	return sal;
}
public void setSal(float sal) {
	this.sal = sal;
}
@Override
public String toString() {
	return super.toString()+" \n SalaryEmp [sal=" + sal + "]";
}

public void salary() {

	double Da = sal*0.15;
	double HRA = sal*0.10;
	double pf = sal*0.12;
	
	double netSalary = sal+Da+HRA-pf;
	System.out.println(netSalary);
}
}


