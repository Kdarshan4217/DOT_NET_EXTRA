package com.demo.beans;

public class Person {
	
	private String name;
	private String mob;
	private String email;
	public Person() {
		super();
	}
	public Person(String name, String mob, String email) {
		super();
		this.name = name;
		this.mob = mob;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "person [name=" + name + ", mob=" + mob + ", email=" + email + "]";
	}
	

}
