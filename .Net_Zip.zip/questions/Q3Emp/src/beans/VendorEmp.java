package beans;

import java.time.LocalDate;

public class VendorEmp extends Employee {
	private int noOfEmp;
	private float amt;

	public VendorEmp(int id, String name, String mob, String emailid, String dept, String desig, LocalDate joindate,int noOfEmp,float amt) {
		super(id, name, mob, emailid, dept, desig);
		this.noOfEmp = noOfEmp;
		this.amt =amt;
		
		}

	public int getNoOfEmp() {
		return noOfEmp;
	}

	
	public void setNoOfEmp(int noOfEmp) {
		this.noOfEmp = noOfEmp;
	}

	public float getAmt() {
		return amt;
	}

	public void setAmt(float amt) {
		this.amt = amt;
	}
	
	@Override
	public String toString() {
		return super.toString() +"VendorEmp [\nnoOfEmp=" + noOfEmp + ",\n amt=" + amt + "]";
	}
	
	public void salary() {
		double sal = amt + amt*0.18;
		System.out.println("Vendor amount : " + sal);
	}

}
