package com.demo.beans;

public class Customer extends Person{
	
	private String memtype;
	private String fpaid;
	
	String s="GCM";
	public static int num = 1;
	private String cid = s.substring(0,3)+num;
	public Customer() {
		super();
	}
	public Customer(String cid,String name, String mob, String email,String memtype, String fpaid ) {
		super(name,mob,email);
		this.memtype = memtype;
		this.fpaid = fpaid;
		this.cid = cid;
	}
	public String getMemtype() {
		return memtype;
	}
	public void setMemtype(String memtype) {
		this.memtype = memtype;
	}
	public String getFpaid() {
		return fpaid;
	}
	public void setFpaid(String fpaid) {
		this.fpaid = fpaid;
	}
	public String getId() {
		return cid;
	}
	public void setId(String id) {
		this.cid = id;
	}
	@Override
	public String toString() {
		return super.toString()+"customer [memtype=" + memtype + ", fpaid=" + fpaid + ", s=" + s + ", id=" + cid + "]";
	}
	
	
	

}
