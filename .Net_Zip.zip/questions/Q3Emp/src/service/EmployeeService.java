package service;

public interface EmployeeService {

	void displayall();

	void searchbyid();

	void searchbyname();

	void acceptdept();

	void searchdsg();

}
