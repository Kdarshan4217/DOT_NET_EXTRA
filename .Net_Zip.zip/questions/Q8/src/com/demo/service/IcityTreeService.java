package com.demo.service;

public interface IcityTreeService {

	void findByCity();

	void deleteCity();

	void addCity();

	void displayAll();

	void findByTree();

}
