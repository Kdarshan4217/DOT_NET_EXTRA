package src.com.java.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public interface ICityDao
{

	List<String> listTrees(String treeName);

	boolean removeList(String cityName);

	boolean addToList(String cityName, String tree1Name, String tree2Name);

	boolean checkCityName(String cityName);

	Map<String, ArrayList<String>> displayInfo();

	boolean addTree(String cityName, String tree1Name);

	boolean findAllTrees(String tree1Name);

	
}
