package src.com.java.dao;
import java.util.*;

public class CityDao implements ICityDao {
	
	private static final int ArrayList = 0;

	static Map<String,ArrayList<String>> hm1;
	
	static ArrayList<String> tlist;
	static List<String> tlist1;
	static List<String> tlist2;
	
	static {
		//Adding Info
		hm1 = new HashMap<String,ArrayList<String>>();

		tlist =new ArrayList<>();
		tlist.add( "neem");
		tlist.add( "tulsi");
		
		ArrayList<String> tlist1 =new ArrayList<>();
		tlist1.add( "Oak");
		tlist1.add( "Rosewood");
		tlist1.add( "tulsi");
		
		ArrayList<String> tlist2 =new ArrayList<>();
		tlist2.add( "Pipal");
		tlist2.add( "Pinewood");

		
		hm1.put("pune",  tlist);
		hm1.put("mumbai", tlist1);
		hm1.put("lucknow", tlist2);
	}
	
	@Override
	public List<String> listTrees(String cityName) {
		if (hm1.containsKey(cityName))
			return  hm1.get(cityName);
		return null;
		
	}

	@Override
	public boolean removeList(String cityName) {
		if (hm1.containsKey(cityName))
			return  hm1.remove(cityName, hm1.get(cityName));
		
		return false;
	}


	@Override
	public boolean addToList(String cityName, String tree1Name, String tree2Name) {
		ArrayList<String> tlist3 = new ArrayList<>();
		tlist3.add(tree2Name);
		tlist3.add(tree1Name);
		hm1.put(cityName,tlist3 );
		
		return true;
	}

	@Override
	public boolean checkCityName(String cityName) {
		if(hm1.containsKey(cityName))
		return true;
		return false;
	}

	@Override
	public Map<String, ArrayList<String>> displayInfo() {	
		return hm1;
	}


	@Override
	public boolean addTree(String cityName, String tree1Name) {
		if(hm1.containsKey(cityName))
		{
			ArrayList<String> newlist= hm1.get(cityName);
					newlist.add(tree1Name);
			hm1.put(cityName, newlist);
			return true;
		}
		
		return false;
	}

	@Override
	public boolean findAllTrees(String tree1Name)
	{
		for(ArrayList<String> v:hm1.values())
		{
		
			for(String k: hm1.keySet())
			{
				
				if(v.contains(tree1Name))	
				{ 
					System.out.println("CityName "+k);
					break;
				}
			}
			
		}
		return true;
	}
	
	
	}
	
	
	
	
	

