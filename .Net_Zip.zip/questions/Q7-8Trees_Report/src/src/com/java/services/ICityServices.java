package src.com.java.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public interface ICityServices {

	List<String> listOfTrees();

	boolean deleteList();

	boolean addTreeToList();

	boolean checkCityExists();

	Map<String, ArrayList<String>> displayAll();

	boolean addNewTree();

	boolean FindTree();

	

	

}
