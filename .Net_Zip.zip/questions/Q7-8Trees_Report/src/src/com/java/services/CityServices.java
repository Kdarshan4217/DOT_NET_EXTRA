package src.com.java.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import src.com.java.dao.*;
import src.com.java.dao.ICityDao;


public class CityServices implements ICityServices 
{
	Scanner sc=new Scanner(System.in);
	
	private ICityDao pdao;
	public CityServices()
	{
		this.pdao = new CityDao();
	}

	@Override
	public List<String> listOfTrees() {
		System.out.println("Enter City Name:");
		String cityName=sc.next();
		return pdao.listTrees(cityName);
	}

	@Override
	public boolean deleteList() {
		System.out.println("Enter City Name:");
		String cityName=sc.next();
		return pdao.removeList(cityName);
	}

	public boolean addTreeToList() {
		System.out.println("Enter City Name:");
		String cityName=sc.next();
		System.out.println("Enter Tree1 Name:");
		String tree1Name=sc.next();
		System.out.println("Enter Tree2 Name:");
		String tree2Name=sc.next();
		return pdao.addToList(cityName,tree1Name,tree2Name);
	}

	@Override
	public boolean checkCityExists() {
		System.out.println("Enter City Name:");
		String cityName=sc.next();
		return pdao.checkCityName(cityName);
	}

	@Override
	public Map<String, ArrayList<String>> displayAll() {
		
		return pdao.displayInfo();
	}

	@Override
	public boolean addNewTree() {
		System.out.println("Enter City Name:");
		String cityName=sc.next();
		System.out.println("Enter Tree1 Name:");
		String tree1Name=sc.next();
		return pdao.addTree(cityName,tree1Name);
	}

	@Override
	public boolean FindTree() {
		System.out.println("Enter Tree1 Name:");
		String tree1Name=sc.next();
		return pdao.findAllTrees(tree1Name);
	}
	
	
	
	}


