package src.com.java.test;

import src.com.java.services.*;

import java.util.*;

public class TestCity {

	public static void main(String[] args) 
	{	
		Scanner sc= new Scanner(System.in);
		
		ICityServices pservice =new CityServices();
		List<String> list1 = new ArrayList<>();
		int ch; 
		
		do {
			System.out.println("--------------------------------------");
		System.out.println("MENU");
		System.out.println("Enter \n 1. Find list of trees \n 2. Delete List \n "
				+ "3. Add new entry \n 4.Check city name\n"
				+ " 5. Display All \n6. Add New Tree\n8.Exit");
		System.out.println("Enter a choice");
		int choice = sc.nextInt();
		
		switch(choice)
		{
		case 1: //Find list of trees
			
		list1=pservice.listOfTrees();
			if (list1.isEmpty())
			{
				
			System.out.println("List Not Found");
			}
			else
			{
				System.out.println(list1);
				System.out.println("List Found");
			}
			break;
		
		case 2: //Delete List
			
			boolean status =pservice.deleteList ();
			if (status)
			{
			System.out.println("List Deleted");
			}
			else
			{
				System.out.println("List Not Deleted");
			}
			break;
			
    case 3: //Add List
			
			 status =pservice.addTreeToList ();
			if (status)
			{
			System.out.println("List Added");
			}
			else
			{
				System.out.println("List Not Added");
			}
			break;
    case 4: //	Check City Exists in List
    	status =pservice.checkCityExists();
		if (status)
		{
		System.out.println("City Already Exists");
		}
		else
		{
			System.out.println("City does not Exists");
		}
		break;
    case 5:
    	Map<String , ArrayList<String>> map1;
    	map1= pservice.displayAll();
    	if(map1.isEmpty())
    	{
    		System.out.println("Error Not Found");
		}
		else
		{
			
			System.out.println("Information Found");
			
			System.out.println(map1);
		}
		break;
    case 6: //Add new tree
    	
    	 status =pservice.addNewTree();
		if (status)
		{
		System.out.println("New Tree Added");
		}
		else
		{
			System.out.println("Error Occured");
		}
		break;
    case 7:
 
    	status =pservice.FindTree();
		if (status)
		{
		System.out.println("Tree Found");
		}
		else
		{
			System.out.println("Tree Not Found");
		}
		break;

		case 8:
			System.out.println("Thankyou Visit Again!!");
			sc.close();
			System.exit(0);
		} 

	
		}while(true);
	}
}
