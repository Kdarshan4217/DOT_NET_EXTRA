package com.demo.test;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.demo.beans.MyExecutor;

public class MyTestExecutorService {

	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(5);
		List<Future> lst = new ArrayList<>();
		for(int i=1; i <=51;i=i+3) {
			MyExecutor e1 = new MyExecutor(i, i+3);
			Future<Integer> f = es.submit(e1);
			lst.add(f);
		}
		int sum = 0;
		for (Future f1: lst) {
			int ans;
				try {
					ans = (Integer) f1.get();
					sum = sum + ans;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		}
		System.out.println("Addition: "+ sum);
		es.shutdown();
		}
	}


