package com.demo.beans;

public interface Customer {
    void assignPlan(String plan);

}
