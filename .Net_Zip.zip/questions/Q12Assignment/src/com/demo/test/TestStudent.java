package com.demo.test;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileReader;
public class TestStudent 
{
	public static void main(String[] args) 
	{
		try(BufferedReader br = new BufferedReader(new FileReader("std.txt"));) 
		{
				String s =br.readLine();
				while(s!=null) 
				{
					System.out.println(s);
					s=br.readLine();
				}
				System.out.println("End of File");
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	
	
	}
}


