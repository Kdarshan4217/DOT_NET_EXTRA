package com.demo.test;
import com.demo.beans.*;
import com.demo.service.*;
import java.util.Scanner;


public class TestStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("1.Add new Student\n2.Display all product\n3.Modify product\n4.delete by id\n5.display by id\n6.exit\n");
		IStudentService service = new StudentService();
		
		int choice =0;
		switch(choice)
		{
		case 1:
			boolean status=service.addNewStudent();
			if(status)
			{
				System.out.println("added sucessfully!");
			}
			else
			{
				System.out.println("error occured");
			}
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;

	}

}
