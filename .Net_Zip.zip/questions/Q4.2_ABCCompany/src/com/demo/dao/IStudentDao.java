package com.demo.dao;

public interface IStudentDao {

	boolean addStudent(int id, String nm, String degree, int marksdegree);

}
