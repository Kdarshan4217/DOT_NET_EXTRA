package com.demo.service;
import java.util.Scanner;

import com.demo.dao.IStudentDao;
import com.demo.dao.StudentDao;
public class StudentService implements IStudentService {
	
	IStudentDao sdao;
	public StudentService ()
	{
		sdao=new StudentDao(); 
	}
	
	Scanner sc = new Scanner(System.in);
	@Override
	public boolean addNewStudent() {
		
		
		System.out.println("enter student id");
		int Id= sc.nextInt();
		System.out.println("enter student name");
		String nm=sc.next();
		System.out.println("enter Degree");
		String degree = sc.next();
		System.out.println("enter Degree marks");
		int marksdegree = sc.nextInt();
		return sdao.addStudent(Id,nm,degree,marksdegree);
	}

}
